# hambugi
hambugi project

프로젝트 개요 : 출결관리 – 캘린더, 알림, 공지 등을 포함

팀 : 햄부기(Hambugi)

팀장 : 김은비

팀원 : 김려원 김원정 박한별 윤나래
